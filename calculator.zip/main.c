
#include <stdio.h>
#include <math.h>

int main()
{
    int num1;
    printf("enter num1  ");
    scanf("%d",&num1);
    int num2;
    printf(" enter num2 ");
    scanf("%d",&num2);
    char op;
    printf("enter operand ");
    scanf("%c%c",&op,&op);
    float result;
    result=0;
    switch(op)
    {
        case '+':
        result=num1+num2;
        break;
        case '-':
        result=num1-num2;
        break;
        case '*':
        result=num1*num2;
        break;
        case '/' :
        result=num1/num2;
        break;
        case '%':
        result=num1%num2;
        break;
    }
    printf("Result: %d %c %d = %f\n",num1,op,num2,result);
    return 0;
}
