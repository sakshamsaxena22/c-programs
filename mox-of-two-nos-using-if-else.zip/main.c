#include <stdio.h>

int main()
{
    int num;
    printf("enter the no.");
    scanf("%d",&num);
        int num1;
    printf("enter the no.");
    scanf("%d",&num1);
    if(num>num1)
    {
        printf("%d"" is greater ",num );
    }
    else
    {
        printf("%d "" is greater " ,num1);
    }
    return 0;
}

