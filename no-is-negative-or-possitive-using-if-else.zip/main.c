#include <stdio.h>

int main()
{
    int num;
    AGAIN:
    AGAIN1:
    AGAIN2:
    printf("enter the no.");
    scanf("%d",&num);

    if(num>0)
    {
        printf("%d"" is possitive ",num );
        goto AGAIN;
    }
    else if (num<0)
    {
        printf("%d""is negative  ",num);
        goto AGAIN1;
    }
    else
    {
        printf("%d "" is zero   ",num);
        goto AGAIN2;
    }
    
    return 0;
}
