#include<stdio.h>
int main()
{
char str [50];
scanf("%s",str);
printf("welcome %s",str);




return 0;
}

