
#include <stdio.h>

int main()
{
    int num1;
    printf("enter num1  ");
    scanf("%d",&num1);

    switch(num1>0)
    {
        case 1:
        printf("%d is positive",num1);
        break;
        case 0:
        switch(num1<0)
        {
            case 1:
            printf("%d no is negative",num1);
            break;
            case 0:
            printf ("%d no is zero",num1);
            break;
        }
        
    }
    return 0;
}
    
