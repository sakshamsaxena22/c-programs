
#include <stdio.h>

int main()
{
    int num;
    printf("enter num  ");
    scanf("%d",&num);
   
    switch(num%2)
    {
        case 0:
        printf("%d, is even");
        break;
        case 1:
        printf("%d is odd");
        break;
        
    }
    return 0;
}
    
