#include <stdio.h>

int main()
{
again:

    int n, factorial = 1;

    printf("Enter a number to calculate its factorial: ");
    scanf("%d", &n);
    if(n==0)
    {
        printf("1\n");
            goto again;
    }
    else{

    for (int i = 1; i <= n; i++)
    {
        factorial *= i;
    }

    printf("Factorial of %d is %d\n", n, factorial);

    }

    return 0;

}
