# include <stdio.h>
int main(){
  int num1,num2,sum,subs,multi,divide;
    printf("enter 1st number:\n");
    scanf("%d",&num1);
    printf("enter 2nd number\n");
    scanf("%d",&num2);
    sum=num1+num2;
    subs=num1-num2;
    multi=num1*num2;
    divide=num1/num2;
    printf("sum=%d\nsubs=%d\nmulti=%d\ndivide=%d",sum,subs,multi,divide);
    return 0;
}
