/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1;
    printf("enter num1  ");
    scanf("%d",&num1);
    int num2;
    printf(" enter num2 ");
    scanf("%d",&num2);
    switch(num1>num2)
    {
        case 0:
        printf("%d is greater");
        break;
        case 1:
        printf("%d is greater");
        break;
        default:
        printf("both are equal");
    }
    
    

    return 0;
}
