#include <stdio.h>

int main()
{
    int num;
    printf("enter the no.");
    scanf("%d",&num);
        int num1;
    printf("enter the no.");
    scanf("%d",&num1);
        int num2;
    printf("enter the no.");
    scanf("%d",&num2);
    if(num>num1)
    {
        printf("%d"" is greater ",num );
    }
    else if (num1>num2)
    {
        printf("%d""is greater",num1);
    }
    else
    {
        printf("%d "" is greater " ,num2);
    }
    return 0;
}