#include <stdio.h>

int main()
{
  char a;
  printf("enter the vowel");
  scanf("%c",&a);
  switch(a)
  {
      case 'a':
      printf("IT IS VOWEL" );
       break;
      case 'e':
      printf("IT IS VOWEL");
       break;
      case 'i':
      printf("IT IS VOWEL");
       break;
      case 'o' :
      printf("IT IS VOWEL");
       break;
      case 'u':
      printf("IT IS VOWEL");
       break;
      case 'A':
      printf("IT IS VOWEL");
       break;
      case 'E':
      printf("IT IS VOWEL");
      break;
        case 'I':
      printf("IT IS VOWEL");
      break;
        case 'O':
      printf("IT IS VOWEL");
      break;
        case 'U':
      printf("IT IS VOWEL");
      break;
      
      
  
default:
printf("IT IS CONSONANT");
}

    return 0;
}

